package com.example.MidtermHw;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;

public class ScanActivity extends AppCompatActivity {


    private BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    private BluetoothManager mBluetoothManager = null;
    private BluetoothLeScanner mBluetoothLeScanner = null;
    private boolean scanning = false;
    ArrayList<BLEDevice> findDevice = new ArrayList<>();
    DeviceAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        setupPermissions(R.layout.activity_scan);
        scan();
        mAdapter.OnItemClick(itemClick);

        //click the button below
        Button button = findViewById(R.id.button_Scan);
        button.setOnClickListener((v)-> {
            if(!scanning){
                scanning = true;
                mBluetoothLeScanner.startScan(mLeScanCallback);
                button.setText("STOP"); //if the moment before clicking the button is fasle
                                        // , representing that it is stop scanning, the button can help start scanning
            } else{
                scanning = false; // if the moment before clicking the button is true
                                // , representing that it is scanning, the button can help stop scanning
                mBluetoothLeScanner.stopScan(mLeScanCallback);
                button.setText("SCAN");
            }
       });
    }

    private static final int PERMISSION_REQUEST_CODE = 666;

    private final static String[] permissionsWeNeed = new String[]{
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.BLUETOOTH,
            Manifest.permission.ACCESS_FINE_LOCATION};

    private void setupPermissions(int activity_main){
        boolean isGranted = true;
        //to check whether the app has permission or not
        for( String permission: permissionsWeNeed){
            ActivityCompat.checkSelfPermission(this, permission);
            isGranted = true;
        }
        //if the user haven't allow the permissionn
        if(!isGranted) {
            //to check the user's version
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int hasgone = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
                //have some chances to get the permission
                if (hasgone != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(permissionsWeNeed, PERMISSION_REQUEST_CODE); //the code represent the id when call back
                }else{
                    //have no chances to get the permission
                    Toast.makeText(this, "NO permission!", Toast.LENGTH_SHORT).show();
                    finishAndRemoveTask(); //end up running the app
                }
            } else initBluetooth(); //open the user's bluetooth

        }
    }

    //when stop scanning
    @Override
    protected void onStop() {
        super.onStop();
        Button button = findViewById(R.id.button_Scan);
        scanning = true;
        button.setText("STOP");
        findDevice.clear();
        mBluetoothLeScanner.startScan(mLeScanCallback);
        mAdapter.clearDevice();
    }

    //when start scanning
    @Override
    protected void onStart() {
        super.onStart();
        Button button = findViewById(R.id.button_Scan);
        scanning = false;
        button.setText("SCAN");
        mBluetoothLeScanner.stopScan(mLeScanCallback);
    }

    //initial the bluetooth
    private void initBluetooth(){
        boolean success = false;
        mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (mBluetoothManager != null){
            mBluetoothAdapter = mBluetoothManager.getAdapter();
            if(mBluetoothAdapter != null) {
                mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();
                Toast.makeText(this,"Bluetooth has started :)", Toast.LENGTH_SHORT).show();
                success = true;
            }
        }
        if(!success){
            Toast.makeText(this, "Can't start bluetooth :(", Toast.LENGTH_SHORT).show();
            finishAndRemoveTask();
        }
    }

    //start scanning
    private void scan() {
        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if(bluetoothManager != null){
            mBluetoothAdapter = bluetoothManager.getAdapter();
            if (mBluetoothAdapter != null){
                mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();
                Toast.makeText(this,"Bluetooth has started :)",Toast.LENGTH_SHORT).show();
            }
        }
        mBluetoothLeScanner.startScan(mLeScanCallback);
        scanning = true;
        RecyclerView recyclerView = findViewById(R.id.recyclerView_ScannedList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAdapter = new DeviceAdapter(this);
        recyclerView.setAdapter(mAdapter);

    }

    private ScanCallback mLeScanCallback = new ScanCallback() {
        //onScanResult
        public void onScanResult(int callbackType, ScanResult result) {
        BluetoothDevice device = result.getDevice();
        ScanRecord scanRecord = result.getScanRecord();
        String address = device.getAddress();
        byte[] data = scanRecord.getBytes();
        new Thread(()->{
            if (address!= null){
                findDevice.add(new BLEDevice(String.valueOf(result.getRssi()), byteArrayToHexString(data), device.getAddress()));
                ArrayList newList = getSingle(findDevice); //call getSingle method
                runOnUiThread(()->{
                    mAdapter.addDevice(newList);
                });
            }
        }).start();
        }
    };

    private DeviceAdapter.OnItemClick itemClick = new DeviceAdapter.OnItemClick(){
        @Override
        public void onItemClick(BLEDevice selectedDevice) {
            //create an intent to detailActivity
            Intent intent = new Intent(ScanActivity.this, DetailActivity.class);
            intent.putExtra(DetailActivity.ADDRESS,selectedDevice.getAddress());
            intent.putExtra(DetailActivity.RSSI,selectedDevice.getRSSI());
            intent.putExtra(DetailActivity.DETAIL,selectedDevice.getDetail());
            intent.putExtra(DetailActivity.KEY,selectedDevice);
            startActivity(intent);
        }
    };

    private int getIndex(ArrayList temp, Object obj) {
        for (int i = 0; i < temp.size(); i++) {
            if (temp.get(i).toString().contains(obj.toString())) {
                return i;
            }
        }
        return -1;
    }

    //getSingle
    private ArrayList getSingle(ArrayList list) {
        ArrayList tempArrayList = new ArrayList<>();
        try {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                Object obj = it.next();
                if (!tempArrayList.contains(obj)) {
                    tempArrayList.add(obj);
                } else {
                    tempArrayList.set(getIndex(tempArrayList, obj), obj);
                }
            }
            return tempArrayList;
        } catch (ConcurrentModificationException e) {
            return tempArrayList;
        }
    }

    //convert byte from Decimal into hexadecimal
    public static String byteArrayToHexString(byte[] b){
        int length = b.length;
        String byt = new String();
        for (int i = 0; i < length; i++){
            byt += Integer.toHexString((b[i] >> 4) & 0xf);
            byt += Integer.toHexString(b[i] & 0xf);
        }
        return byt;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode == KeyEvent.KEYCODE_BACK){
            if(getApplicationInfo().targetSdkVersion >= Build.VERSION_CODES.ECLAIR){
                event.startTracking();
            }else {
                onBackPressed();
            }}
        return false;
    }
}
