package com.example.MidtermHw;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DeviceAdapter extends RecyclerView.Adapter<DeviceAdapter.ViewHolder>{

    //variable
    private List<BLEDevice> arrayList = new ArrayList<>();
    private OnItemClick onItemClick;
    private Activity activity ;

    //add in the arraylist
    public void addDevice(List<BLEDevice> arrayList){
        this.arrayList = arrayList;
        notifyDataSetChanged();
    }

    //clear the arraylist
    public void clearDevice(){
        this.arrayList.clear();
        notifyDataSetChanged();
    }

    //click
    public void OnItemClick(OnItemClick onItemClick){
        this.onItemClick = onItemClick;
    }

    //adapter
    public DeviceAdapter(Activity activity) {
        this.activity = activity;
    }

    //viewholder of recyclerview
    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView address;
        TextView rssi;
        Button button;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            address = itemView.findViewById(R.id.ScanAddress);
            rssi = itemView.findViewById(R.id.ScanRssi);
            button = itemView.findViewById(R.id.buttonDetail);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.address.setText("Address:："+arrayList.get(position).getAddress());
        holder.rssi.setText("Rssi:："+arrayList.get(position).getRSSI());
        holder.button.setOnClickListener(v -> {
            onItemClick.onItemClick(arrayList.get(position));
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }
    interface OnItemClick{
        void onItemClick(BLEDevice selectedDevice);
    }
}
