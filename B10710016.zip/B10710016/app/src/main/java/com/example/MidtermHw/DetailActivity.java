package com.example.MidtermHw;

import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    public static final String ADDRESS = "";
    public static final String RSSI = "";
    public static final String DETAIL = "";

    public static final String KEY = "";
    public BLEDevice bled;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        //create top bar and back button
        getSupportActionBar().setTitle("Detail");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //get the textview by id
        TextView address = findViewById(R.id.dtAddress);
        TextView rssi = findViewById(R.id.dtRssi);
        TextView detail = findViewById(R.id.dtDetail);

        //create a bled object
        bled = (BLEDevice) getIntent().getSerializableExtra(KEY);

        //set the information into bledevice object we've created just before
        address.setText(bled.getAddress());
        rssi.setText(bled.getRSSI());
        detail.setText(bled.getDetail());
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (getApplicationInfo().targetSdkVersion >= Build.VERSION_CODES.ECLAIR) {
                event.startTracking();
            } else{
                onBackPressed();
            }
        }
        return false;
    }
}