package com.example.MidtermHw;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;

public class BLEDevice implements Serializable {

    //variables
    public String rssi;
    public String address;
    public String detail;

    //constructor of bledevice, including address, rssi, detail
    public BLEDevice(String rssi, String detail, String address) {
        this.rssi = rssi;
        this.detail = detail;
        this.address = address;
    }

    //GET METHOD
    public String getRSSI() {
        return rssi;
    }

    //GET METHOD
    public String getAddress() {
        return address;
    }

    //GET METHOD
    public String getDetail() {
        return detail;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        BLEDevice b = (BLEDevice)obj;
        return this.address.equals(b.address);
    }

    @NonNull
    @Override
    public String toString() {
        return this.address;
    }
}
